Static assets folder reserved for future app assets. The current app is self-contained in index.html.
