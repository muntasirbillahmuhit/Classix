# CLASSIX Calculator

A standalone, mobile-first scientific calculator app built from the supplied `classix.html`.

## Run locally / in an AI Studio Node environment

```bash
npm install
npm run dev
```

For a production build:

```bash
npm run build
npm run preview
```

Vite serves the root `index.html`. The original calculator HTML, CSS, and JavaScript are kept together in that file; no React conversion or external runtime dependency is required.

## Import into Google AI Studio

1. Upload/import this entire project folder or its ZIP/repository, not only `classix.html`.
2. Make sure the project root is the folder containing `package.json` and `index.html`.
3. If AI Studio asks for a start command, use `npm run dev`.
4. If it asks for a build command, use `npm run build`.
5. If it asks for an output directory, use `dist`.

## Important

The app is intentionally kept as a vanilla HTML/CSS/JavaScript app. Do not replace it with a mockup or rewrite it into another framework unless explicitly requested. Preserve the calculator's existing layout, key interactions, calculation logic, settings, and localStorage behavior.
